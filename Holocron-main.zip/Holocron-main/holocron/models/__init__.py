from . import detection, segmentation
from .classification import *
