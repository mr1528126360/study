.. role:: hidden
    :class: hidden-section

holocron.utils.data
===================

.. currentmodule:: holocron.utils.data


Batch collate
-------------

.. autofunction:: Mixup
