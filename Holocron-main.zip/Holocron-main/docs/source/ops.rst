holocron.ops
============

.. currentmodule:: holocron.ops

:mod:`holocron.ops` implements operators that are specific for Computer Vision.

.. note::
  Those operators currently do not support TorchScript.

Boxes
-----

.. autofunction:: box_giou
.. autofunction:: diou_loss
.. autofunction:: ciou_loss
