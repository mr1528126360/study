holocron.transforms
===================

.. automodule:: holocron.transforms

.. currentmodule:: holocron.transforms

:mod:`holocron.transforms` provides PIL and PyTorch tensor transformations.


.. autoclass:: Resize
    :members:


.. autoclass:: RandomZoomOut
    :members:
