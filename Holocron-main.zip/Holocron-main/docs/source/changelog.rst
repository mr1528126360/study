Changelog
=========

v0.2.1 (2022-07-16)
-------------------
Release note: `v0.2.1 <https://github.com/frgfm/Holocron/releases/tag/v0.2.1>`_

v0.2.0 (2022-02-05)
-------------------
Release note: `v0.2.0 <https://github.com/frgfm/Holocron/releases/tag/v0.2.0>`_

v0.1.3 (2020-10-27)
-------------------
Release note: `v0.1.3 <https://github.com/frgfm/Holocron/releases/tag/v0.1.3>`_

v0.1.2 (2020-06-21)
-------------------
Release note: `v0.1.2 <https://github.com/frgfm/Holocron/releases/tag/v0.1.2>`_

v0.1.1 (2020-05-12)
-------------------
Release note: `v0.1.1 <https://github.com/frgfm/Holocron/releases/tag/v0.1.1>`_

v0.1.0 (2020-05-11)
-------------------
Release note: `v0.1.0 <https://github.com/frgfm/Holocron/releases/tag/v0.1.0>`_
