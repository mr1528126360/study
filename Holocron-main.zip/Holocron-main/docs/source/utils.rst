holocron.utils
===============

.. automodule:: holocron.utils

.. currentmodule:: holocron.utils

:mod:`holocron.utils` provides some utilities for general usage.


Miscellaneous
-------------

.. autofunction:: find_image_size
