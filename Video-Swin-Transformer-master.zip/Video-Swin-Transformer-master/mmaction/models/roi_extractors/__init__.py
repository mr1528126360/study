from .single_straight3d import SingleRoIExtractor3D

__all__ = ['SingleRoIExtractor3D']
