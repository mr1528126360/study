---
name: General questions
about: Ask general questions to get help
title: ''
labels: ''
assignees: ''

---

Before raising a question, you may need to check the following listed items.

**Checklist**

1. I have searched related issues but cannot get the expected help.
2. I have read the [FAQ documentation](https://mmaction2.readthedocs.io/en/latest/faq.html) but cannot get the expected help.
